import { useState } from "react";
import TeacherCalendar from "./components/TeacherCalendar";

export default function TimetableTeacherPage() {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());

  const handlePrevMonth = () => {
    const newDate = new Date(year, month - 1);
    setYear(newDate.getFullYear());
    setMonth(newDate.getMonth());
  };

  const handleNextMonth = () => {
    const newDate = new Date(year, month + 1);
    setYear(newDate.getFullYear());
    setMonth(newDate.getMonth());
  };

  // ★修正点1: 引数 'date' に Date 型を明示
  const handleDateClick = (date: Date) => {
    console.log("クリックした日付:", date);
  };

  return (
    <div className="p-6">
      {/*
        ★修正点2: このエラーは TeacherCalendar.tsx 側の修正で解消されます。
        以下のコード自体に変更はありません。
      */}
      <TeacherCalendar
        year={year}
        month={month}
        onPrevMonth={handlePrevMonth}
        onNextMonth={handleNextMonth}
        onDateClick={handleDateClick}
      />
    </div>
  );
}
